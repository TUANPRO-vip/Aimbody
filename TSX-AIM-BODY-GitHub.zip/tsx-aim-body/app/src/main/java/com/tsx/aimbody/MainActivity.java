package com.tsx.aimbody;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(16, 11, 26), purple = Color.rgb(183,124,255), panel = Color.rgb(38,27,57);
    private LinearLayout root;
    private TextView status;
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(22));
        if (stroke != 0) d.setStroke(dp(1), stroke); return d;
    }
    private TextView label(String text, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); build();
    }
    private void build() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(22)); root.setBackgroundColor(bg);
        setContentView(root);
        TextView title = label("✦  TSX AIM BODY  ✦", 24, purple, true); root.addView(title, new LinearLayout.LayoutParams(-1, dp(54)));
        TextView sub = label("AIM ASSISTANT  •  ANDROID", 11, Color.LTGRAY, true); root.addView(sub, new LinearLayout.LayoutParams(-1, dp(28)));
        View spacer = new View(this); root.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1));
        TextView aim = label("◎\nAIM BODY", 27, Color.WHITE, true); aim.setLineSpacing(dp(8), 1f); aim.setBackground(shape(panel, purple));
        LinearLayout.LayoutParams aimLp = new LinearLayout.LayoutParams(dp(210), dp(210)); aimLp.gravity = Gravity.CENTER; root.addView(aim, aimLp);
        TextView caption = label("CHỌN TRÒ CHƠI", 12, Color.LTGRAY, true); LinearLayout.LayoutParams c = new LinearLayout.LayoutParams(-1, dp(56)); c.topMargin = dp(22); root.addView(caption,c);
        Button choose = new Button(this); choose.setText("FREE FIRE     ▶"); choose.setTextColor(Color.WHITE); choose.setAllCaps(false); choose.setTextSize(16); choose.setBackground(shape(panel,purple));
        root.addView(choose, new LinearLayout.LayoutParams(-1, dp(58)));
        choose.setOnClickListener(v -> showOptions());
        status = label("Không root  •  Chọn tệp theo quyền Android", 11, Color.rgb(190,175,210), false);
        LinearLayout.LayoutParams s = new LinearLayout.LayoutParams(-1, dp(52)); s.topMargin = dp(14); root.addView(status,s);
        View bottom = new View(this); root.addView(bottom, new LinearLayout.LayoutParams(1, 0, 1));
    }
    private void showOptions() {
        new android.app.AlertDialog.Builder(this).setTitle("Free Fire")
          .setItems(new String[]{"Chọn tệp cấu hình", "Mở Free Fire nếu đã cài"}, (dialog, which) -> {
              if (which == 0) pickFile(); else openGame();
          }).setNegativeButton("Hủy", null).show();
    }
    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, 42);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == 42 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData(); status.setText("Đã chọn tệp: " + (uri.getLastPathSegment() == null ? "tệp cấu hình" : uri.getLastPathSegment()) + "\nChỉ nhập/chọn tệp; không tự ghi vào dữ liệu riêng của game.");
            Toast.makeText(this,"Đã chọn tệp",Toast.LENGTH_SHORT).show();
        }
    }
    private void openGame() {
        String[] ids = {"com.dts.freefireth", "com.dts.freefiremax"};
        for (String id : ids) { Intent i = getPackageManager().getLaunchIntentForPackage(id); if (i != null) { startActivity(i); return; } }
        Toast.makeText(this,"Không tìm thấy Free Fire đã cài trên máy.",Toast.LENGTH_LONG).show();
    }
}
