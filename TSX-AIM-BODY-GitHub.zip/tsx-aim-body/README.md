# TSX AIM BODY

Android Studio/Gradle project with a purple-black UI, AIM BODY center panel, Free Fire selection menu, document picker, and optional launch of an installed Free Fire app.

## Build on GitHub using a phone
1. Create a new GitHub repository.
2. Upload the contents of this folder (not the enclosing folder) to the repository root.
3. Open the **Actions** tab and enable Actions if prompted.
4. Select **Build TSX AIM BODY APK** and press **Run workflow** (or push to `main`).
5. Open the completed workflow run, scroll to **Artifacts**, and download `TSX-AIM-BODY-APK.zip`. Extract `app-debug.apk` and install it on your phone.

The app uses Android's document picker to select a file. It does not copy files into Free Fire's private/protected data directories.
